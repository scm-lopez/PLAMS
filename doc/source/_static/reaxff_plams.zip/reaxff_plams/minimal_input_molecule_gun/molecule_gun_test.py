mol = Molecule('mol.xyz')
oxy = Molecule('oxy.xyz')

s = Settings()
s.input.control = load_reaxff_control('orig/control')
s.input.ffield = 'CHO.ff'
s.input.geo.descrp = 'molgun-test'

s.input.molecule_gun.veladd = 3
s.input.molecule_gun.firstadd = 500
s.input.molecule_gun.freqadd = 5000
s.input.molecule_gun.startx = 40.90998606
s.input.molecule_gun.starty = 63.6082715
s.input.molecule_gun.startz = 55.26141405
s.input.molecule_gun.rotate = 1
s.input.molecule_gun.taddmol = 800
s.input.molecule_gun.velxyz = (-5.8246594, 6.00241546, -0.79708398)

j = MoleculeGunJob(name='reaxtest', settings=s, molecule=mol, bullet=oxy)
j.run()