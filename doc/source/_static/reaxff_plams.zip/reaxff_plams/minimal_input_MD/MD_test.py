mol = Molecule('mol.xyz')

s = Settings()
s.input.control.itrans = 1
s.input.control.icobo  = 1
s.input.control.icentr = 0
s.input.control.imetho = 0
s.input.control.igeofo = 1
s.input.control.irecon = 25
s.input.control.ixmolo = 5
s.input.control.ichupd = 1
s.input.control.icharg = 4
s.input.control.mdtemp = 298.00
s.input.control.tdamp1 = 100.0
s.input.control.icheck = 0
s.input.control.nrstep = 0
s.input.control.imdmet = 1
s.input.control.tstep  = 0.250
s.input.control.mdpres = 0.00000
s.input.control.pdamp1 = 500.0
s.input.control.inpt   = 0
s.input.control.nmdit  = 40000
s.input.control.iout1  = 50
s.input.control.iout2  = 1000000
s.input.control.iout3  = 1
s.input.control.ivels  = 0
s.input.control.iout6  = 2000
s.input.control.iout7  = 50
s.input.control.irten  = 25
s.input.control.npreit = 0
s.input.control.range  = 0.00
s.input.control.endmm  = 1.000
s.input.control.imaxmo = 1
s.input.control.imaxit = 40000
s.input.control.iout4  = 1
s.input.control.icelop = 0
s.input.control.optcel = 0
s.input.control.icelo2 = 0
s.input.control.drmax  = 0.10000
s.input.control.imcfrq = 0
s.input.control.imcstp = 500

s.input.ffield = 'CHO.ff'

j = ReaxFFJob(name='MD', settings=s, molecule=mol)
j.run()