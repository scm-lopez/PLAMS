mol = Molecule('mol.xyz')

s = Settings()
s.input.control = load_reaxff_control('orig/control')
s.input.contol.icheck = 0 #I use the same values as in the loaded control file, so it doesn't really make sense here, but wanted to show how it's done
s.input.contol.mdtemp = 298.0

s.input.ffield = 'CHO.ff' #can be a path to file or a filename from $ADFHOME/atomicdata/ForceFields/ReaxFF

s.input.geo.descrp = 'geo-opt-test' #this has to be present, if not supplied, PLAMS will use the job name here
s.input.geo.fixatoms = ['1 1', '2 2'] #list allows multiple occurences of the same keyword

s.runscript.nproc = 2 #use 2 cores

j = ReaxFFJob(name='reaxtest', settings=s, molecule=mol)
j.run()