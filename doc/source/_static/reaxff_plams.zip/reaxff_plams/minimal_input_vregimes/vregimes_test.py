mol = Molecule('mol.xyz')

s = Settings()
s.input.control = load_reaxff_control('orig/control')
s.input.ffield = 'CHO.ff'
s.input.geo.descrp = 'test'
s.input.external = ['orig/vregime.in']

j = ReaxFFJob(name='reaxtest', settings=s, molecule=mol)
j.run()